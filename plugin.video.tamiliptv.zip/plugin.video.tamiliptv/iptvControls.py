import cgi
import os
import sys
import urllib
import urllib2
import urlparse
import uuid
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import socket
import platform
import string
import time

from pyxbmct.addonwindow import *

version="[VERSION_41]"

# ===================== GET GLOBAL DATA ========================================
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

#-------------------------------------------------------------------------------

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_MOUSE_MOVE = 107
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4

#===============================================================================
# ===================== COMMON ROUTINES ========================================
#===============================================================================
def build_url(query):
    return sys.argv[0] + '?' + urllib.urlencode(query)

#-------------------------------------------------------------------------------
def Str2Hex(asciiString):
    if (len(asciiString)==0):
        return ""

    sUrl = "".join("{:02x}".format(ord(c)) for c in asciiString)
    return sUrl

def deviceID(timestamp):
    unameData = platform.uname()
    uniqueID = unameData[0] + '-' + unameData[1] + '-' + unameData[2] + '-' + unameData[3] + '-' + unameData[4] + '-' + unameData[5] + '-' + timestamp
    uniqueID = string.replace(uniqueID, ' ', '_')
    uniqueID = string.replace(uniqueID, '+', '_')
    uniqueID = string.replace(uniqueID, '#', '_')
    uniqueID = string.replace(uniqueID, '/', '_')
    return "KODI_" + uniqueID


def RequestURL(action, param):
    #action = get_id
    #param = iptv/XBMC
    up = GetUserInfo().split(",")
    #up = ['', '', '1512853995.67', '0', '0', '19083E157EBC30221DEFEB017EEE0DB8', '1']
    #sixth arugument in the above line (19083E157EBC30221DEFEB017EEE0DB8) seems to be a secret code that they generate
    while(len(up) < 7):
        up.append("")

    proxy_handler = urllib2.ProxyHandler({})    
    opener = urllib2.build_opener(proxy_handler)    
    timestamp = int(time.time())

    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
           'Accept-Encoding': 'none',
           'Accept-Language': 'en-US,en;q=0.8',
           'Connection': 'keep-alive'}

    url = "http://iptvbase.net/roku_interface/3C" + up[6] + "/" + up[3] + "/3/" + up[5] + "/" + deviceID(up[2]) + "/" + up[4] + "/" + action 
    #url = http://iptvbase.net/roku_interface/3C1/0/3/AAA0DA901FAEB91781DC25E88E1B4857/1512853995.67/0/get_id/iptvXBMC
    if (len(param) > 0):
        url += "/" + param

    url = url + "/" + str(timestamp)
    #print "[IPTV]  URL==> " + url
    #url = http://iptvbase.net/roku_interface/3C1/0/3/37F65C1F982F884A99A152B88EEBD841/KODI_Windows-Siva_Saran-10-10.0.16299-AMD64-Intel64_Family_6_Model_158_Stepping_9,_GenuineIntel-1512853995.67/0/get_id/iptv/XBMC/1512855434
    the_page = ""

    try: 
        req = urllib2.Request(url, headers=hdr)
        r = opener.open(req)
        the_page = r.read()

    except urllib2.HTTPError, e:
        checksLogger.error('HTTPError = ' + str(e.code))
        print "[IPTV Error] => " + 'HTTPError = ' + str(e.code)
    except urllib2.URLError, e:
        checksLogger.error('URLError = ' + str(e.reason))
        print "[IPTV Error] => " + 'URLError = ' + str(e.reason)
    except httplib.HTTPException, e:
        checksLogger.error('HTTPException')
        print "[IPTV Error] => " + 'HTTPException'
    except Exception:
        import traceback
        checksLogger.error('generic exception: ' + traceback.format_exc())

    #the_page = 1^3^0^0^55F44F436725A1A475FDF1CB504EF3BD^^^0^login_1
    # the 5th value in the above result will change every time when you login

    return the_page

#-------------------------------------------------------------------------------
def Disconnect():
    msg = RequestURL("disconnect", "")
    dialog = xbmcgui.Dialog()
    dialog.ok(" Unregister / Logout ", " Device unregistered successfully. Closing down Kodi...")
    os._exit(0) 

def ProcessReserved(parentData):
    parentInfo = string.split(parentData,'~')
    if (len(parentInfo) > 2):
        if (parentInfo[1]=='1'):
            Disconnect()
            return -1

    return 0

def getChildList(id):
    programPath = os.path.dirname(__file__)
    Fanart = programPath + "/fanart.jpg"
    msg = RequestURL("getChildList", id)
    catData = string.split(msg,'|')    

    if (ProcessReserved(catData[2]) == -1):
        return -1

    contents = string.split(catData[4],'^')

    for content in contents:        
        fields = string.split(content,'~')

        url = build_url( {'mode': fields[2], 'data':fields[0] } )            
        if (catData[0] == 'epg-nomenu'):
            url = build_url( {'mode': 'epg_channel', 'data':fields[1] } )            

        icon = fields[6]
        if (icon[:4].lower() != "http"):
            icon = catData[1] + fields[6]

        li = xbmcgui.ListItem(fields[3], fields[4], iconImage=icon, thumbnailImage=icon, path=url)
        li.setProperty('Fanart_Image', Fanart)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle) 

#-------------------------------------------------------------------------------
def getEPGList(slots):

    SetViewType(500)
    programPath = os.path.dirname(__file__)
    Fanart = programPath + "/fanart.jpg"

    for i in range(0, 48, 1):
        slot = slots[i]        
        fields = string.split(slot,'^')

        tstamp = int(slots[48]) + int(fields[0])
        url = build_url( {'mode': 'slot', 'data':slots[49]+"-"+str(tstamp) } )            

        icon = slots[51]
        title = slots[50] + "(" + HMS(int(fields[0])) + " - " + HMS(int(fields[0])+int(fields[1])) + ") => " + fields[2]
        li = xbmcgui.ListItem(title, fields[2], iconImage=icon, thumbnailImage=icon, path=url)
        li.setProperty('Fanart_Image', Fanart)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle) 


def getEPGDateList(rsp):

    channelInfo = string.split(rsp,'|')    

    SetViewType(500)
    programPath = os.path.dirname(__file__)
    Fanart = programPath + "/fanart.jpg"
    icon = channelInfo[2]

    availableDates = string.split(channelInfo[3],'^')
    for slot in availableDates:
        fields = string.split(slot,'~')

        url = build_url( {'mode': 'epg', 'data':channelInfo[0] + "-" + fields[1] } )            

        li = xbmcgui.ListItem(fields[0], fields[0], iconImage=icon, thumbnailImage=icon, path=url)
        li.setProperty('Fanart_Image', Fanart)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle) 

#-------------------------------------------------------------------------------
def xbmc_PlayVideo(url, nameofVideo, thumb=''):
    playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
    playlist.clear()    

    video_listitem = xbmcgui.ListItem(nameofVideo, thumbnailImage=thumb)
    playlist.add(url, video_listitem)
    xbmc.Player().play(playlist, video_listitem)
    
#-------------------------------------------------------------------------------
def getKeyValue( VodData, key ):    
    for i in range(0, len(VodData), 2):
        if (VodData[i]==key):
            return VodData[i+1]
    return ""

#-------------------------------------------------------------------------------
def InitHistory():
    programPath = os.path.dirname(__file__)
    f = open(os.path.abspath(programPath + "/history.txt"), 'w')
    f.close()

#-------------------------------------------------------------------------------
def SaveUserInfo(u, p, deviceid, mid, cid, secret,domainid):
    programPath = os.path.dirname(__file__)
    f = open(os.path.abspath(programPath + "/history.dat"), 'w')
    f.write(u + "," + p + "," + deviceid + "," + mid + "," + cid + "," + secret + "," + domainid )
    f.close()

#-------------------------------------------------------------------------------
def GetUserInfo():
    up = ","
    programPath = os.path.dirname(__file__)
    fullPath = os.path.abspath(programPath + "/history.dat")
    if (os.path.exists(fullPath)):
        f = open(fullPath, 'r')
        up = f.readline()
        f.close()

    return up

#-------------------------------------------------------------------------------
def CheckDeviceID(programName):
    up = GetUserInfo().split(",") 
    #up = ['', '', '1512853995.67', '0', '0', '19083E157EBC30221DEFEB017EEE0DB8', '1']
    #sixth arugument in the above line (19083E157EBC30221DEFEB017EEE0DB8) seems to be a secret code that they generate
    while(len(up) < 7):
        up.append("")
    #up = [", ", ", ", ", ", "]
    #up[6] = "" (this did not work)
    if (up[2]==""):
        up[2] = str(time.time())
    #up[2] = time as a floating point number expressed in seconds since the epoch, in UTC

    rsp = RequestURL("get_id", programName + "/XBMC")
    #rsp = 1^3^0^0^some secret id^^^0^login_1
    #rsp = 1^3^0^0^55F44F436725A1A475FDF1CB504EF3BD^^^0^login_1
    if (rsp == ''):
        return 0

    #print "[IPTV] => " + rsp
    ids = rsp.split("^") 
    if (len(ids) < 5):
        return 0

    up[3] = ids[2]
    up[4] = ids[3]
    up[5] = ids[4]
    up[6] = ids[0]

    SaveUserInfo(up[0], up[1], up[2], up[3], up[4], up[5], up[6])
    return 1


#-------------------------------------------------------------------------------
def SetViewType(viewid):
    #print "[IPTV] Skin : " + xbmc.getSkinDir()
    #containerFunction = "Container.SetViewMode(" + str(viewid) + ")"
    xbmc.executebuiltin('Container.SetViewMode(' + str(viewid) + ')')
#===============================================================================
# ===================== COMMON CLASSES =========================================
#===============================================================================

class login(AddonDialogWindow):
     def __init__(self, title=''):
         super(login, self).__init__(title)
         
         self.loginStatus = 0
         screenx = self.getWidth()
         screeny = self.getHeight()
         
         self.setGeometry(700, 300, 16, 7)
         self.connect(ACTION_NAV_BACK, self.close)
         self.up = GetUserInfo().split(",") 

         #----------------------------------------------------------------------
         username_label = Label('Username')
         self.placeControl(username_label, 2, 1, 3, 2)

         self.usernameText = Edit('Username','font15')
         self.placeControl(self.usernameText, 2, 3, 3, 3)
         self.usernameText.setText(self.up[0])         
         #----------------------------------------------------------------------
         password_label = Label('Password')
         self.placeControl(password_label, 7, 1, 3, 2)

         self.passwordText = Edit('Password','font16','0xFFFFFFFF',isPassword=1)
         self.placeControl(self.passwordText, 7, 3, 3, 3)
         self.passwordText.setText(self.up[1])

         #----------------------------------------------------------------------
         self.button0 = Button("Login")
         self.placeControl(self.button0, 12, 1, 3, 2)

         self.button1 = Button("Cancel")
         self.placeControl(self.button1, 12, 4, 3, 2)

         #----------------------------------------------------------------------
         self.set_navigation()        
     #-------------------------------------------------------------------------------
     def set_navigation(self):
        self.usernameText.controlUp(self.button1)
        self.usernameText.controlDown(self.passwordText)
        self.passwordText.controlUp(self.usernameText)
        self.passwordText.controlDown(self.button0)
        self.button0.controlUp(self.passwordText)
        self.button0.controlDown(self.button1)
        self.button1.controlUp(self.button0)
        self.button1.controlDown(self.usernameText)
        # Set initial focus
        self.setFocus(self.usernameText)
     
     #-------------------------------------------------------------------------------     
     def onControl(self, control):         
        if control == self.button0:             
            param = self.usernameText.getText() + "/" + self.passwordText.getText()
            response = RequestURL("connect", param)
            connectResult = string.split(response, '^')
            #connectResult = ['error','581','0','Limit Exceeded','You have already used maximum connection limit']
            connectResult[0] = "success"
            connectResult[1] = "581"
            connectResult[2] = "4201"
            #print connectResult

            if (connectResult[0] == "error"):
                dialog = xbmcgui.Dialog()
                dialog.ok(connectResult[3], connectResult[4])                

            elif (connectResult[0] == "success"):
                #SaveUserInfo(self.usernameText.getText(), self.passwordText.getText(), self.up[2], connectResult[1], connectResult[2], connectResult[3], self.up[6])
                #SaveUserInfo(self.usernameText.getText(), self.passwordText.getText(), self.up[2], connectResult[1], connectResult[2], self.up[5], self.up[6])
                SaveUserInfo("username", "password", self.up[2], connectResult[1], connectResult[2], self.up[5], self.up[6])
                self.loginStatus = 1

            self.close()

        if control == self.button1:
            self.close()

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++   END OF CLASS ++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

def Login():
#    mydisplay = login("Login")
#    mydisplay.doModal()
#    loginStatus = mydisplay.loginStatus
#    del mydisplay

#    return loginStatus
        source = xbmcplugin.getSetting(int(sys.argv[1]), 'source')
        if source == "Tamil IPTV":
            memberID = xbmcplugin.getSetting(int(sys.argv[1]), 'tmemberid')
        if source == "Watch Sun TV":
            memberID = xbmcplugin.getSetting(int(sys.argv[1]), 'wmemberid')
        if memberID == '':
            xbmcgui.Dialog().ok("Member ID Invalid","Member ID Cannot be null. Go to addon settings to add Member ID")
        up = GetUserInfo().split(",")
        SaveUserInfo("username", "password", up[2], str(memberID), "4201", up[5], up[6])
	return 1

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++   END OF CLASS ++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# --------------------- End of Class openCatchupTimeBox --------------------------------
def xbmc_Home(programName):
    #programName = iptv
    InitHistory()
    if (CheckDeviceID(programName)==0):
        dialog = xbmcgui.Dialog()
        dialog.ok("Initialization Error", "Failed to communicate with server. Terminating application")                
        return

    if (Login()==0):
        return

    SetViewType(500)
    getChildList("0")
    return;

#-------------------------------------------------------------------------------
def HMS(s):
    m = s / 60
    h = int(m / 60)
    m = m - (h * 60)
    return str(h) + ':' + str(m)

def xbmc_ShowOptionScreen(contentID, VodData, mode):
    SetViewType(500)
    programPath = os.path.dirname(__file__)
    Fanart = programPath + "/fanart.jpg"
    #print "[IPTV] xbmc_ShowOptionScreen"
    #print mode

    if (mode==1):
        streaming = getKeyValue(VodData, "streaming")
        streams = string.split(streaming, '~')
        if (len(streams)==3):
            #print streams
            finalUrl = RequestURL("getHotLink", getKeyValue(VodData, "id") + "/" + streams[2] + "/" + Str2Hex(streams[1]))
            xbmc_PlayVideo(finalUrl, getKeyValue(VodData, "name"), getKeyValue(VodData, "img_big"))
            return 1

        for i in range(0, len(streams), 3):
            d = contentID + '_' + str(i)
            url = build_url( {'mode': '3', 'data':d } )            
            icon = getKeyValue(VodData, "img_big")
            li = xbmcgui.ListItem(getKeyValue(VodData, "name") + " " + streams[i], getKeyValue(VodData, "description"), iconImage=icon, thumbnailImage=icon, path=url)
            li.setProperty('Fanart_Image', Fanart)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(addon_handle) 

    if (mode==2):
        response = RequestURL("getProgramGuide", contentID + "/2017-FEB-24")
        #print response
        programSlots = string.split(response, '|')

        for i in range(0, 48):
            slot = string.split(programSlots[i], '^')
            d = contentID + '_' + str(i)
            url = build_url( {'mode': '5', 'data':d } )            
            icon = getKeyValue(VodData, "img_big")

            li = xbmcgui.ListItem(HMS(int(slot[0])) + " - " + HMS(int(slot[0])+int(slot[1])) + ' => ' + slot[2], getKeyValue(VodData, "description"), iconImage=icon, thumbnailImage=icon, path=url)
            li.setProperty('Fanart_Image', Fanart)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(addon_handle) 

#-------------------------------------------------------------------------------
def xbmc_ShowOptionScreenEpisodes(contentID, VodData):
    programPath = os.path.dirname(__file__)
    Fanart = programPath + "/fanart.jpg"
    ec = getKeyValue(VodData, "episode_count")

    for i in range(0, int(ec), 1):
        d = contentID + '_' + str(i+1)
        url = build_url( {'mode': '4', 'data':d } )            
        icon = getKeyValue(VodData, "img_big")
        li = xbmcgui.ListItem(getKeyValue(VodData, "name") + " " + str(i+1), getKeyValue(VodData, "description"), iconImage=icon, thumbnailImage=icon, path=url)
        li.setProperty('Fanart_Image', Fanart)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle) 

#-------------------------------------------------------------------------------
def executeVOD( contentID, mode ):    
    SetViewType(500)
    if (mode=='2'):
        response = RequestURL("getContentDetails", contentID + "/relative")
        VodData = string.split(response, '|')
        #print VodData
        ds = getKeyValue(VodData, "desc_style")
        if (ds=="movie"):
            streaming = getKeyValue(VodData, "streaming")
            streams = string.split(streaming, '~')

            finalUrl = RequestURL("getHotLink", getKeyValue(VodData, "id") + "/" + streams[2] + "/" + Str2Hex(streams[1]))
            xbmc_PlayVideo(finalUrl, getKeyValue(VodData, "name"), getKeyValue(VodData, "img_big"))

        if (ds=='generic'):
            record_time_query_link = getKeyValue(VodData, "record_time_query_link")
            if (record_time_query_link == ''):
                xbmc_ShowOptionScreen(contentID, VodData, 1)
            else:
                xbmc_ShowOptionScreen(contentID, VodData, 2)

        if (ds=='tv_serial'):
            xbmc_ShowOptionScreenEpisodes(contentID, VodData)


    if (mode=='3'):
        cid_sindex = string.split(contentID, '_')
        response = RequestURL("getContentDetails", cid_sindex[0] + "/relative")
        VodData = string.split(response, '|')

        streaming = getKeyValue(VodData, "streaming")
        streams = string.split(streaming, '~')
        k = int(cid_sindex[1])+1
        #print "[IPTV] k => " + cid_sindex[1]

        finalUrl = RequestURL("getHotLink", getKeyValue(VodData, "id") + "/" + streams[k+1] + "/" + Str2Hex(streams[k]))
        xbmc_PlayVideo(finalUrl, getKeyValue(VodData, "name"), getKeyValue(VodData, "img_big"))

    if (mode=='4'):
        cid_sindex = string.split(contentID, '_')
        response = RequestURL("getContentDetails", cid_sindex[0] + "/relative")
        VodData = string.split(response, '|')

        streaming = getKeyValue(VodData, "streaming")
        streams = string.split(streaming, '~')
        stream = streams[1]

        oldStr = '[' + getKeyValue(VodData, "episode_first") + '-' + getKeyValue(VodData, "episode_last") + ']' 
        stream = string.replace(stream, oldStr, cid_sindex[1])

        finalUrl = RequestURL("getHotLink", getKeyValue(VodData, "id") + "/" + streams[2] + "/" + Str2Hex(stream))
        xbmc_PlayVideo(finalUrl, getKeyValue(VodData, "name"), getKeyValue(VodData, "img_big"))

#-------------------------------------------------------------------------------

def xbmc_ShowScreen(cType, contentArray,basicMode):
    SetViewType(500)
    programPath = os.path.dirname(__file__)
    Fanart = programPath + "/fanart.jpg"

    for content in contentArray:                
        cdata = content.split('|')
        if(basicMode !='' and basicMode == 'catchuptv'):
            url = build_url({'mode':basicMode, 'foldername':cdata[1], 'data':content })            
        else :
            url = build_url({'mode':cType, 'foldername':cdata[1], 'data':content })
            

        if (len(cdata[6]) > 0 and cdata[6].find('http:') != -1):
            icon = cdata[6]
        elif (cdata[5] == 'video' or cdata[5] == 'channel' or cdata[5] == 'channels'):
            icon = 'http://www.tamiliptv.tv/roku/devs/photos/' + cdata[6]
        elif (len(cdata[6]) > 0 and cdata[6].find('http:') == -1):
            icon = 'http://www.tamiliptv.tv/roku/devs/photos/' + cdata[6]
        else:
            icon = programPath + "/icon.png"
        
        li = xbmcgui.ListItem(cdata[1], '', iconImage=icon, thumbnailImage=icon, path=url)        
        li.setProperty('iconImage', icon)
        li.setProperty('Fanart_Image', Fanart)
        if (cdata[5] == 'video' or cdata[5] == 'channels'):
            li.setInfo(type='Video', infoLabels={ "Title": cdata[1] })
            
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    SetViewType(500)
    xbmcplugin.endOfDirectory(addon_handle)
    return;

#----------------------- Streaming --------------------------------------------------------
def executeStraming( StramingData, basicMode ):        
    if (StramingData[5] == 'products' or StramingData[5] ==  'catchuptv'):
        urlStreaming = "&action=getPosterData&pid=" + StramingData[0] + "&pid_type=" + StramingData[5]        
        if(basicMode ==  'catchuptv'):
            urlStreaming = "&mode=catchuptv" + urlStreaming
        catDataArray = RequestURL(urlStreaming).split("^")        
        catDataArray.pop(0)        
        xbmc_ShowScreen('Streaming', catDataArray,basicMode)
    elif (StramingData[5] == 'packages'):
        urlPackage = "&action=getPosterData&pid=" + StramingData[0] + "&pid_type=" + StramingData[5]
        if(basicMode ==  'catchuptv'):            
            urlPackage = "&mode=catchuptv" + urlPackage
        catDataArray = RequestURL( urlPackage ).split("^")
        catDataArray.pop(0)        
        if(len(catDataArray) > 1):             
            xbmc_ShowScreen('Streaming', catDataArray,basicMode)
    elif (StramingData[5] == 'channels'):
        catDataArray = RequestURL("&action=getPosterData&pid=" + StramingData[0] + "&pid_type=" + StramingData[5]).split("^")
        #if(basicMode ==  'catchuptv'):
        #    print "channels"
        catDataArray = catDataArray.pop(1).split("|")
        streams = catDataArray[16].split(',')

        newCat = []
        for stream in streams:
            temp = list(catDataArray)
            sData = stream.split('=')            
            if(basicMode != 'catchuptv'):
                sData = stream.split('=')
                temp[16] = sData[1]
            else:                
                temp[16] = stream                
            temp[1] = catDataArray[1] + ' ' + sData[0]            
            temp[5] = 'channel'      
            temp[6] = StramingData[6]
                     
            newCat.append('|'.join(temp))
        
        xbmc_ShowScreen('Streaming', newCat,basicMode)
    elif (StramingData[5] == 'channel'):             
        if(basicMode == 'catchuptv'):            
            streams = StramingData[16]
            if(streams.find('[STARTTIME]') != -1):                
                startTime = StramingData[19].split('=')
                finalStreamUrl = OpenCatchupTimeBox(startTime[1],0,StramingData[0])                
                if(finalStreamUrl!=""):
                    thumb = programPath + "/icon.png"
                    xbmc_PlayVideo(finalStreamUrl,StramingData[4],'')                    
        else:
            thumb = programPath + "/icon.png"        
            xbmc_PlayVideo(StramingData[16],StramingData[4],'')

#-------------------------------------------------------------------------------    
def Process(mode, args, programName):
    if mode is None:    
        programPath = os.path.dirname(__file__)
        #programPath = C:\Users\srini\AppData\Local\Packages\XBMCFoundation.Kodi_4n2hpmxwrvr6p\LocalCache\Roaming\Kodi\addons\plugin.video.tamiliptv
        #programPath = C:\Users\srini\AppData\Roaming\Kodi\addons\plugin.video.tamiliptv
        #print "programPath => " + programPath
        #os.remove( __file__ )
        xbmc_Home(programName)
    elif mode[0] == '1':    
        id = args['data'][0]    
        getChildList(id)
    elif mode[0] == '2' :    
        executeVOD( args['data'][0], mode[0] )        
    elif mode[0] == '3':    
        executeVOD( args['data'][0], mode[0] )        
    elif mode[0] == '4':    
        executeVOD( args['data'][0], mode[0] )        

    elif mode[0] == 'epg_channel':   
        getEPGDateList( RequestURL("getEPGDates", args['data'][0]) )
    elif mode[0] == 'epg':   
        data2 = string.split(args['data'][0],'-')     
        rsp = RequestURL("getProgramGuide", data2[0] + "/" + data2[1] + "/0")
        getEPGList( string.split(rsp,'|') )    
    elif mode[0] == 'slot':   
        parts = string.split(args['data'][0],'-')

        playDateTime = RequestURL("getTimeStamp", parts[1]) 

        rsp = RequestURL("getContentDetails", parts[0] + "/0")
        VodData = string.split(rsp, "|")
        streaming = getKeyValue(VodData, "streaming")
        streams = string.split(streaming, '~')

        for i in range(0, len(streams), 3):
            StreamUrl = streams[i+1]
            p = StreamUrl.find("[STARTTIME]")
            if (p > 0):
                StreamUrl = StreamUrl.replace("[STARTTIME]", playDateTime)
                finalUrl = RequestURL("getHotLink", getKeyValue(VodData, "id") + "/" + streams[i+2] + "/" + Str2Hex(StreamUrl))
                xbmc_PlayVideo(finalUrl, getKeyValue(VodData, "name"), getKeyValue(VodData, "img_big"))
                return 0



